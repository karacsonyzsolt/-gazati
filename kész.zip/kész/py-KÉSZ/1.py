import math
import random
print("1. feladat: Védőfólia kalkulátor")
a=int(input("Adja meg az óra átmérőjét (mm): "))
szin=["ezüst","arany","fekete","kék","rózsaszín"]
print(f"Az ön órájához válaszott szín: {random.choice(szin)}")
print(f"Az óra számlapjához szükséges védőfólia területe: {((a*a)*math.pi)/4:.2f} mm2")