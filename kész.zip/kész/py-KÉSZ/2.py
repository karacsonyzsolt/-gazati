import datetime

def current_time() -> list[int,int]:
    hour=datetime.datetime.now().hour
    minute=datetime.datetime.now().minute
    return[hour,minute]

def time_input(uzenet,min,max):
    ertek=int(input(uzenet))
    while ertek<min or ertek>max:
        print(f"Megadott érték nem megfelelő, {min} és {max} közötti értéket adjon meg!")
        ertek=int(input(uzenet))
    return ertek

ora=time_input("Adja meg az órat: ",0,23)
perc=time_input("Adja meg a percet: ",0,59)
ido=ora*60+perc

current=current_time()
print(f"Az aktuális idő: {current[0]}:{current[1]}")
akt_ido=current[0]*60+current[1]

if akt_ido>ido:
    print("A vizsga már véget ért.")
else:
    print(f"A vizsga végéig hátralévő idő: {ido-akt_ido} perc")