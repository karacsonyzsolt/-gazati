class Watch:
    def __init__(self,sor:str):
        adatok=sor.strip().split(";")
        self.model=adatok[0]
        self.brand=adatok[1]
        self.szin=adatok[2]
        self.ar=float(adatok[3])
        
watch:list[Watch]=[]
file=open("watches.csv","r",encoding="utf-8")
fejlec=file.readline()
for sor in file:
    watch.append(Watch(sor))
file.close()

print("3. feladat: Luxus órák")
print(f"3.3 feladat: A nyilvántartásban szereplő órák száma: {len(watch)}")

szin=input("3.4 feladat: Adja meg az óra számlapjának színét: ")
van=False
szamlalo=0
for i in watch:
    if szin==i.szin:
        szamlalo+=1
        van=True
if van==True:
    print(f"{szin} színű számlappal rendelkező órák száma: {szamlalo}.")
else:
    print("Nincs a megadott számlappal rendelkező óra.")

maxora=watch[0].ar
model=""
gyarto=""
for i in watch:
    if maxora<i.ar:
        maxora=i.ar
        model=i.model
        gyarto=i.brand
print(f"A legdrágább óra adatai:\n\tModel: {model}\n\tGyártója: {gyarto}\n\tÁr: {maxora} USD")

print("3.6 feladat: Statisztika a gyártók szerint:")
stat={}
for i in watch:
    if i.brand not in stat:
        stat[i.brand]=1
    else:
        stat[i.brand]+=1

for i in stat:
    if stat[i]>0:
        print(f"\t{i}: {stat[i]} darab")